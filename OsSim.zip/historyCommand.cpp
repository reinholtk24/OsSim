#include "command.hpp"

bool historyCommand::execute()
{

    return true;
}

bool historyCommand::execute(std::string input)
{
    std::cout << "whoo" << std::endl;
}
