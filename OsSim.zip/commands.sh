alias quit complete / date / version
 
